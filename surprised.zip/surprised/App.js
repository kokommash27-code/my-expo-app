import { View, Text, Button } from 'react-native';

export default function App() {
  return (
    <View
      style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f2f2f2',
      }}
    >

      {/* Card */}
      <View
        style={{
          width: 300,
          padding: 20,
          backgroundColor: 'white',
          borderRadius: 15,

          // ظل (Shadow)
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 5 },
          shadowOpacity: 0.2,
          shadowRadius: 10,

          elevation: 5, // مهم لأندرويد
        }}
      >

        <Text
          style={{
            fontSize: 22,
            fontWeight: 'bold',
            marginBottom: 10,
            textAlign: 'center',
          }}
        >
          بطاقة المستخدم
        </Text>

        <Text
          style={{
            fontSize: 16,
            color: '#555',
            marginBottom: 20,
            textAlign: 'center',
          }}
        >
          هذه بطاقة تصميم احترافي داخل تطبيق React Native
        </Text>

        <Button
          title="اضغط هنا"
          onPress={() => {
            alert('تم الضغط على البطاقة');
          }}
        />

      </View>

    </View>
  );
}